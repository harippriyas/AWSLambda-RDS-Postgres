from dataclasses import dataclass
import psycopg2
from psycopg2.extras import RealDictCursor
import json
import boto3
from botocore.exceptions import ClientError


conn = psycopg2.connect(
    host =      "dbhost.region.rds.amazonaws.com",
    database =  "dbname",
    user =      "postgres",
    password =  "password"
)

def lambda_handler(event, context):
    cur = conn.cursor(cursor_factory = RealDictCursor)
    cur.execute("select * from users limit 10")
    results = cur.fetchall()
    json_result = json.dumps(results)
    print(json_result)
    cur.close()
    return json_result
    
